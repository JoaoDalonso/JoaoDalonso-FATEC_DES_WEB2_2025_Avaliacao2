<?php
session_start();
class Login{
    private $user='admin';
    private $pass='admin';
    public function verificar_credenciais($login,$senha){
        if($login===$this->user && $senha===$this->pass){
            $_SESSION['logged_in']=true;
            return true;
        }
        return false;
    }
    public function verificar_logado(){
        if(empty($_SESSION['logged_in'])){
            $this->logout();
        }
        return true;
    }
    public function logout(){
        session_unset();
        session_destroy();
        header('Location:index.php');
        exit;
    }
}
