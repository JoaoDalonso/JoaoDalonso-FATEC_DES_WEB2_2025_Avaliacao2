<?php
define('DB_HOST','127.0.0.1');
define('DB_NAME','artesanato_db');
define('DB_USER','root');
define('DB_PASS','root');
define('DB_CHARSET','utf8mb4');
