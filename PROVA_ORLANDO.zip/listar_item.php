<?php
require_once 'class_login.php';
require_once 'class_banco.php';
$auth = new Login();
$auth->verificar_logado();
$db = new DB();
$produtos = $db->getAllProducts();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Produtos – Lojinha</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f3f4f6;
    padding: 20px;
  }
  .card {
    background: #fff;
    max-width: 800px;
    margin: 0 auto;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
  .card h2 {
    text-align: center;
    color: #333;
    margin-bottom: 24px;
  }
  .table-wrapper {
    overflow-x: auto;
  }
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #eee;
  }
  th {
    background: #6c63ff;
    color: #fff;
  }
  tbody tr:hover {
    background: #f1f1f1;
  }
  .button-group {
    text-align: right;
    margin-top: 24px;
  }
  .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
  }
  .btn-secondary {
    background: #e0e0e0;
    color: #333;
    transition: background 0.3s;
  }
  .btn-secondary:hover {
    background: #cfcfcf;
  }
</style>
</head>
<body>
  <div class="card">
    <h2>Lista de Produtos</h2>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Preço</th>
            <th>Descrição</th>
            <th>Categoria</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($produtos as $p): ?>
            <tr>
              <td><?= $p['id'] ?></td>
              <td><?= htmlspecialchars($p['nome_produto']) ?></td>
              <td>R$ <?= number_format($p['preco'],2,',','.') ?></td>
              <td><?= htmlspecialchars($p['descricao']) ?></td>
              <td><?= htmlspecialchars($p['categoria']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="button-group">
      <a href="home.php" class="btn btn-secondary">← Voltar</a>
    </div>
  </div>
</body>
</html>
