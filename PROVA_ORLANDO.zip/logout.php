<?php
require_once 'class_login.php';
$auth=new Login();
$auth->logout();
header('Location:index.php');
