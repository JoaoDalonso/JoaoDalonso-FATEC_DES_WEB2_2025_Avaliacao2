<?php
require_once 'class_login.php';
$auth=new Login();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $user=$_POST['login']??'';
    $pass=$_POST['senha']??'';
    if($auth->verificar_credenciais($user,$pass)){
        header('Location:home.php');
        exit;
    }else{
        header('Location:index.php');
        exit;
    }
}
$auth->logout();
