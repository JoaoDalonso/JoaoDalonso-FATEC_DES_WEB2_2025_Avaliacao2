<?php
require_once 'credenciais.php';
class DB{
    private $pdo;
    public function __construct(){
        $dsn="mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        try{
            $this->pdo=new PDO($dsn,DB_USER,DB_PASS);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
            die("Erro na conexão:".$e->getMessage());
        }
    }
    public function __destruct(){
        $this->pdo=null;
    }
    public function addProduct($nome,$preco,$descricao,$categoria){
        $sql="INSERT INTO produtos_artesanais(nome_produto,preco,descricao,categoria)VALUES(:nome,:preco,:descricao,:categoria)";
        $stmt=$this->pdo->prepare($sql);
        $stmt->execute([':nome'=>$nome,':preco'=>$preco,':descricao'=>$descricao,':categoria'=>$categoria]);
    }
    public function removeProduct($id){
        $sql="DELETE FROM produtos_artesanais WHERE id=:id";
        $stmt=$this->pdo->prepare($sql);
        $stmt->execute([':id'=>$id]);
    }
    public function getAllProducts(){
        $stmt=$this->pdo->query("SELECT * FROM produtos_artesanais ORDER BY id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
