<?php
require_once 'class_login.php';
require_once 'class_banco.php';
$auth = new Login();
$auth->verificar_logado();
$db = new DB();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db->addProduct($_POST['nome'], $_POST['preco'], $_POST['descricao'], $_POST['categoria']);
    header('Location: home.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cadastrar Produto – Lojinha</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f3f4f6;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    min-height: 100vh;
  }
  .card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 40px;
    max-width: 500px;
    width: 100%;
  }
  .card h2 {
    margin-bottom: 24px;
    color: #333;
    text-align: center;
  }
  .form-group {
    margin-bottom: 16px;
  }
  .form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
  }
  .form-group input,
  .form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
  }
  .form-group textarea {
    resize: vertical;
    min-height: 100px;
  }
  .button-group {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 24px;
  }
  .btn {
    padding: 12px 24px;
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    cursor: pointer;
  }
  .btn-primary {
    background: #6c63ff;
    color: #fff;
    transition: background 0.3s;
  }
  .btn-primary:hover {
    background: #5149d4;
  }
  .btn-secondary {
    background: #e0e0e0;
    color: #333;
    text-decoration: none;
    text-align: center;
    transition: background 0.3s;
  }
  .btn-secondary:hover {
    background: #cfcfcf;
  }
</style>
</head>
<body>
  <div class="card">
    <h2>Cadastrar Produto</h2>
    <form method="post">
      <div class="form-group">
        <label for="nome">Nome do Produto</label>
        <input type="text" id="nome" name="nome" required maxlength="100">
      </div>
      <div class="form-group">
        <label for="preco">Preço (ex: 19.90)</label>
        <input type="text" id="preco" name="preco" required pattern="\d+(\.\d{2})?">
      </div>
      <div class="form-group">
        <label for="descricao">Descrição</label>
        <textarea id="descricao" name="descricao" required maxlength="255"></textarea>
      </div>
      <div class="form-group">
        <label for="categoria">Categoria</label>
        <input type="text" id="categoria" name="categoria" required maxlength="30">
      </div>
      <div class="button-group">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <a href="home.php" class="btn btn-secondary">← Voltar</a>
      </div>
    </form>
  </div>
</body>
</html>
