-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12/05/2025 às 22:27
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `artesanato_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos_artesanais`
--

CREATE TABLE `produtos_artesanais` (
  `id` int(11) NOT NULL,
  `nome_produto` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos_artesanais`
--

INSERT INTO `produtos_artesanais` (`id`, `nome_produto`, `preco`, `descricao`, `categoria`) VALUES
(1, 'Sabonete Artesanal de Lavanda', 12.50, 'Sabonete 100% natural com essência de lavanda e óleo de coco.', 'Higiene'),
(2, 'Velas Decorativas Aromáticas', 29.90, 'Conjunto de 3 velas com aromas variados: baunilha, canela e rosas.', 'Decoração'),
(3, 'Colar de Miçangas Coloridas', 18.00, 'Feito à mão com miçangas recicladas. Peça única.', 'Bijuteria'),
(4, 'Caderno Artesanal Costurado à Mão', 35.00, 'Capa dura com tecido floral. Papel reciclado.', 'Papelaria'),
(5, 'Macramê para Parede - Mandala', 65.00, 'Peça decorativa feita com fios de algodão cru.', 'Decoração'),
(6, 'Kit de Cosméticos Naturais', 89.90, 'Inclui creme corporal, bálsamo labial e óleo essencial.', 'Cosméticos'),
(7, 'Porta-copos em Crochê (conjunto com 4)', 22.00, 'Porta-copos coloridos feitos em crochê artesanal.', 'Utilidades'),
(8, 'Bolsa de Crochê com Alça de Madeira', 120.00, 'Bolsa exclusiva feita à mão em fio de malha.', 'Moda'),
(9, 'Quadro Decorativo em Madeira Reutilizada', 75.00, 'Frase motivacional pintada à mão.', 'Decoração'),
(10, 'Brinco de Argola com Pedras Naturais', 28.50, 'Brinco feito com arame banhado e pedras naturais.', 'Bijuteria'),
(12, 'Robertixo', 99.90, 'O tal do louco', 'DEV');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `produtos_artesanais`
--
ALTER TABLE `produtos_artesanais`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `produtos_artesanais`
--
ALTER TABLE `produtos_artesanais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
