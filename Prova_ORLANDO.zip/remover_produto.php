<?php
require_once 'class_login.php';
require_once 'class_banco.php';
$auth = new Login();
$auth->verificar_logado();
$db = new DB();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    if ($id) $db->removeProduct($id);
    header('Location: home.php');
    exit;
}
$produtos = $db->getAllProducts();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Remover Produto – Lojinha</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f3f4f6;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    min-height: 100vh;
  }
  .card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    padding: 40px;
    max-width: 500px;
    width: 100%;
  }
  .card h2 {
    margin-bottom: 24px;
    color: #333;
    text-align: center;
  }
  .form-group {
    margin-bottom: 16px;
  }
  .form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
  }
  .form-group select {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
    background: #fff;
  }
  .button-group {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 24px;
  }
  .btn {
    padding: 12px 24px;
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
  }
  .btn-primary {
    background: #e74c3c;
    color: #fff;
    transition: background 0.3s;
  }
  .btn-primary:hover {
    background: #c0392b;
  }
  .btn-secondary {
    background: #e0e0e0;
    color: #333;
    transition: background 0.3s;
  }
  .btn-secondary:hover {
    background: #cfcfcf;
  }
</style>
</head>
<body>
  <div class="card">
    <h2>Remover Produto</h2>
    <form method="post">
      <div class="form-group">
        <label for="id">Selecione o produto</label>
        <select id="id" name="id">
          <?php foreach($produtos as $p): ?>
            <option value="<?= $p['id'] ?>">
              <?= htmlspecialchars($p['nome_produto']) ?> (ID <?= $p['id'] ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="button-group">
        <button type="submit" class="btn btn-primary">Remover</button>
        <a href="home.php" class="btn btn-secondary">← Voltar</a>
      </div>
    </form>
  </div>
</body>
</html>
